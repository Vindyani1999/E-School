package com.example.loginsingupauth

data class Features_DataClass(var title:String, var image:Int)
