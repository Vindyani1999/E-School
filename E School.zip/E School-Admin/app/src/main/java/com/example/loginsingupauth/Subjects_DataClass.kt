package com.example.loginsingupauth

data class Subjects_DataClass(var title:String, var image:Int)

