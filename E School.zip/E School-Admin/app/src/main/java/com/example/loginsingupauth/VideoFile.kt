package com.example.loginsingupauth

data class VideoFile(
    var fileName: String? = null,
    var downloadUrl: String? = null
)
