package com.example.loginsingupauth

data class ChildItem(val title : String , val image : Int)
