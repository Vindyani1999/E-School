package com.example.loginsingupauth

data class Grades_DataClass(var title:String, var image:Int)

