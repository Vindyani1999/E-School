package com.example.loginsingupauth;

import android.app.Activity;

public class MainActivity2 extends Activity {


}
